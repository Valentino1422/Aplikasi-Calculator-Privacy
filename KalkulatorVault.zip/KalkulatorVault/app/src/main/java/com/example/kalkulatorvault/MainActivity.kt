package com.example.kalkulatorvault

import android.animation.ObjectAnimator
import android.animation.ValueAnimator
import android.os.Bundle
import android.view.View
import android.view.animation.LinearInterpolator
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import android.widget.ViewFlipper
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.gridlayout.widget.GridLayout
import java.util.Locale

class MainActivity : AppCompatActivity() {
    private lateinit var tvDisplay: TextView
    private lateinit var viewFlipper: ViewFlipper
    private var currentInput = "0"
    private val secretCode = "1234"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        viewFlipper = findViewById(R.id.view_flipper)
        tvDisplay = findViewById(R.id.tv_display)
        val buttonGrid = findViewById<GridLayout>(R.id.button_grid)

        for (i in 0 until buttonGrid.childCount) {
            val child = buttonGrid.getChildAt(i)
            if (child is Button) {
                child.setOnClickListener {
                    handleInput(child.text.toString())
                }
            }
        }

        setupVaultDashboard()
    }

    private fun setupVaultDashboard() {
        // Initialize feature items in the vault dashboard
        setupFeature(findViewById(R.id.feature_photos), android.R.drawable.ic_menu_gallery, "128", "Private Photos")
        setupFeature(findViewById(R.id.feature_videos), android.R.drawable.ic_menu_slideshow, "42", "Secure Videos")
        setupFeature(findViewById(R.id.feature_files), android.R.drawable.ic_menu_save, "15", "Hidden Files")
        setupFeature(findViewById(R.id.feature_locker), android.R.drawable.ic_lock_lock, "Active", "App Locker")
    }

    private fun setupFeature(view: View, iconRes: Int, count: String, name: String) {
        view.findViewById<ImageView>(R.id.feature_icon).setImageResource(iconRes)
        view.findViewById<TextView>(R.id.feature_count).text = count
        view.findViewById<TextView>(R.id.feature_name).text = name
    }

    private fun handleInput(key: String) {
        when (key) {
            "AC", "C" -> {
                currentInput = "0"
            }
            "=" -> {
                if (currentInput == secretCode) {
                    openVault()
                } else {
                    try {
                        currentInput = evaluateExpression(currentInput)
                    } catch (e: Exception) {
                        currentInput = "Error"
                    }
                }
            }
            else -> {
                val inputKey = when (key) {
                    "÷" -> "/"
                    "×" -> "*"
                    "−" -> "-"
                    else -> key
                }
                
                if (currentInput == "0" && inputKey.all { it.isDigit() }) {
                    currentInput = inputKey
                } else {
                    currentInput += inputKey
                }
            }
        }
        
        tvDisplay.text = if (currentInput.length > 8) currentInput.substring(0, 8) else currentInput
    }

    private fun openVault() {
        viewFlipper.displayedChild = 1 // Switch to Ghost Vault Dashboard
        currentInput = "0"
        tvDisplay.text = "0"
    }

    private fun evaluateExpression(expression: String): String {
        return try {
            val result = simpleEval(expression)
            if (result % 1.0 == 0.0) {
                result.toLong().toString()
            } else {
                String.format(Locale.US, "%.2f", result)
            }
        } catch (e: Exception) {
            "Error"
        }
    }

    private fun simpleEval(expr: String): Double {
        return object : Any() {
            var pos = -1
            var ch = 0

            fun nextChar() {
                ch = if (++pos < expr.length) expr[pos].code else -1
            }

            fun eat(charToEat: Int): Boolean {
                while (ch == ' '.code) nextChar()
                if (ch == charToEat) {
                    nextChar()
                    return true
                }
                return false
            }

            fun parse(): Double {
                nextChar()
                val x = parseExpression()
                if (pos < expr.length) throw RuntimeException("Unexpected: " + ch.toChar())
                return x
            }

            fun parseExpression(): Double {
                var x = parseTerm()
                while (true) {
                    if (eat('+'.code)) x += parseTerm()
                    else if (eat('-'.code)) x -= parseTerm()
                    else return x
                }
            }

            fun parseTerm(): Double {
                var x = parseFactor()
                while (true) {
                    if (eat('*'.code)) x *= parseFactor()
                    else if (eat('/'.code)) x /= parseFactor()
                    else return x
                }
            }

            fun parseFactor(): Double {
                if (eat('+'.code)) return parseFactor()
                if (eat('-'.code)) return -parseFactor()
                var x: Double
                val startPos = pos
                if (eat('('.code)) {
                    x = parseExpression()
                    eat(')'.code)
                } else if (ch >= '0'.code && ch <= '9'.code || ch == '.'.code) {
                    while (ch >= '0'.code && ch <= '9'.code || ch == '.'.code) nextChar()
                    x = expr.substring(startPos, pos).toDouble()
                } else {
                    throw RuntimeException("Unexpected: " + ch.toChar())
                }
                return x
            }
        }.parse()
    }
}
